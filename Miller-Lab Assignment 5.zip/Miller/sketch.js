

function setup() {
  createCanvas(400, 400);
}



function draw() {
  background(220);
  let value = 0;

  textAlign(CENTER);
  textSize(16);

  // Display the mouse's coordinates.
  text(`x: ${mouseX} y: ${mouseY}`, 50, 50);
  
  
  
  fill(value)
  
  
  fill(255)
  rect(100, 100,200)
  rect(195, 300,10, 50)
  rect(150, 350, 100, 10)
  
  
  
  ellipseMode(RADIUS);
  fill(255);
  ellipse(250, 250, 20, 20);
  
  ellipseMode(CENTER);
  fill(100);
  ellipse(250, 250, 20, 20);
  
  

  
  if (keyIsPressed) {
    fill(0);
  } else {
    fill(255);
  }
  
  strokeWeight(3)
  
  
  
  square(100,375, 20)
  square(125,375, 20)
  square(150,375, 20)
  square(175,375, 20)
  square(200,375, 20)
  square(225,375, 20)
  square(250,375, 20)
  square(275,375, 20)
  
  
   fill(value);

  
  rect(120, 250, 50, 10)
  
  
}
let value = 0
function mouseClicked() {
  
  
  if (value === 0) {
    value = 255;
  } else {
    value = 0;
  }
  
   return false;


  
  }






