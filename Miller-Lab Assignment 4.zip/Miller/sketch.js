function setup() {
  createCanvas(400, 400);
}



let value = 0;

function draw() {
  background(220);

  frameRate(5)
  
  fill(value);
  square (60, 60, 60);
 
  let space = 10;
  strokeWeight(5);
  
  for (let x = space; x < 100; x += space) {
    
  for (let y = space; y < 100; y += space) {
    point(x,y);
  }
  }
  circle (200,200,200,60);
  let d = 155;
  let minSize = 5;
    while (d > minSize) {
       circle (200,200,d);
      d -= random(5,15);
    }





}

function mouseClicked(){
  if (value === 0) {
    value = 200;
  }  else {
    value = 0
  }
}


  function mousePressed(){
  value += 25;
    if (value > 150);{
      value = 0;
  }
  
  
  
  
}