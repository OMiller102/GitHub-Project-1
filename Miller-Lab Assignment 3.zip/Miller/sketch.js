function setup() {
  createCanvas(400, 400);
}

function draw() {
  

background(50);
  
  
  // creates cicles that moves across the screen and when holding down left click over the canvas decreases framerate.
  let location = frameCount %400;
    if (mouseIsPressed === true) {
      frameRate(7);
    }  else{
      frameRate(60);
    }
  
  circle(location,300, 30);
  fill("yellow")
  
   if (mouseIsPressed === true) {
      frameRate(7);
    }  else{
      frameRate(60);
    }
  
  circle(location,275, 10);
  fill("yellow")
  
   if (mouseIsPressed === true) {
      frameRate(7);
    }  else{
      frameRate(60);
    }
  
  circle(location,325, 10);
  fill("yellow")
  
  
  colorMode(RGB, 100);


// Creates x and y text on top of screen that tracks cordantes of the mouse when hovering over canvas.
  textAlign(TOP);
  textSize(15);
  
    text(`x: ${mouseX} y: ${mouseY}`, 50, 50);
  
  fill("orange")
  
  
// Creates a line that follows the cursor around.  
  let pmx = pmouseX - 0;
  let pmy = pmouseY - 0;
  let mx = mouseX - 0;
  let my = mouseY - 0;
  
  line (pmx, pmy, mx, my);
  
// creates a series of black dots that get higher over a fast period of time
  scale(20, -1);
  translate(10, -250)
  
  let x = frameCount %5;
  let y = 5 * sqrt(x);
  
  point(x, y);

















}